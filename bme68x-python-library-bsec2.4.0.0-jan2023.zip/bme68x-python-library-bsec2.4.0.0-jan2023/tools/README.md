Tools
=====

- **I bmerawdata**

I bmerawdata
---------------

This tool allows you to record and save data with your [BME688 Breakout Board](https://buyzero.de/products/luftqualitatssensor-bosch-bme688-breakout-board?_pos=2&_sid=985505100&_ss=r), so that it can be imported by [Boschs AI Studio](https://www.bosch-sensortec.com/software-tools/software/bme688-software/).
To use the smell detection feature of the BME688 you need to train an algorithm in AI Studio.
The algorithm requires lots of training and testing data, which you can record using this tool.
**[Read this guide](https://picockpit.com/raspberry-pi/teach-bme688-how-to-smell/)** for detailed instructions.
